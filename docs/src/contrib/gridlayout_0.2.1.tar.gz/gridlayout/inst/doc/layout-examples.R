## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  out.width = "100%",
  echo = FALSE, 
  results='asis'
)

library(gridlayout)
library(glue)
layout_tables <- list(
    stack = "
  |1rem  |1fr      |
  |80px  |header   |
  |1fr   |chickens |
  |1fr   |treePlot |
  |1fr   |stockTable |",
  scrolling_stack = "
  |1rem  |1fr        |
  |80px  |header     |
  |400px |chickens   |
  |400px |treePlot   |
  |400px |stockTable |",
  four_panel = "
  |1rem |1fr        |1fr      |
  |1fr  |header     |chickens |
  |1fr  |stockTable |treePlot |",
  focal_chart_top = "
  |1rem |1fr       |1fr      |
  |80px |header    |header   |
  |2fr  |chickens  |chickens |
  |1fr  |treePlot  |stockTable |",
  focal_chart_side = "
  |1rem |2fr      |1fr      |
  |80px |header   |header   |
  |1fr  |chickens |treePlot |
  |1fr  |chickens |stockTable |"
)


print_layout_info <- function(layout_id = "stack") {
  glue(
    "```  \n",
    "my_layout <- new_gridlayout(\"",
    "{layout_tables[[layout_id]]}\")  \n",
    "```  \n",
    "<img src=layout-examples_{layout_id}.png width = 100%/>"
  )
}

## ----app_code, eval = FALSE, message=FALSE------------------------------------
#  library(gridlayout)
#  library(shiny)
#  library(ggplot2)
#  library(gt)
#  library(dplyr)
#  library(bslib)
#  
#  app_w_layout <- function(my_layout) {
#    shinyApp(
#      ui = grid_page(
#        layout = my_layout,
#        grid_card_text("header", "My gridlayout app"),
#        grid_card(
#          "chickens",
#          card_body(
#            tabsetPanel(
#              tabPanel("Plot", plotOutput("chickPlot")),
#              tabPanel("Fastest growing", gt_output("chickTable")),
#            )
#          )
#        ),
#        grid_card_plot("treePlot"),
#        grid_card(
#           "stockTable",
#          gt_output("stockTable")
#        ),
#        flag_mismatches = FALSE # Allows us to use layouts without some elements declared
#      ),
#      server = function(input, output) {
#  
#        output$chickPlot <- renderPlot({
#          ggplot(
#            ChickWeight,
#            aes(
#              x = Time,
#              y = weight,
#              group = Chick,
#              color = Diet
#            )
#          ) +
#            geom_line(alpha = 0.5) +
#            ggtitle("Chick weights by diet")
#        })
#  
#        output$chickTable <- render_gt({
#          ChickWeight %>%
#            group_by(Chick) %>%
#            summarise(
#              `Diet` = first(Diet),
#              `start weight` = first(weight),
#              `end weight` = last(weight),
#              `weight change rate` = (last(weight) - first(weight)) / last(Time)
#            ) %>%
#            arrange(desc(`weight change rate`)) %>%
#            head(8) %>%
#            gt() %>%
#            tab_header(
#              title = "8 fastest growing chicks"
#            ) %>%
#            fmt_number(
#              columns = c(`start weight`,`end weight`),
#              pattern = "{x}<sub>g</sub>",
#              decimals = 1
#            ) %>%
#            fmt_number(
#              columns = c(`weight change rate`),
#              pattern = "{x}<sub>g/day</sub>",
#              decimals = 2
#            )
#        },
#        height = "100%",
#        width = "100%")
#  
#        output$treePlot <- renderPlot({
#          ggplot(
#            trees,
#            aes(y = Height, x = Volume, size = Girth*2)
#          ) +
#            geom_point(alpha = 0.6) +
#            scale_radius() +
#            labs(
#              title = "Tree height and volume and diameter",
#              size = "Diameter"
#            )
#        })
#  
#        output$yarnPlot <- renderPlot({
#          ggplot(
#            warpbreaks,
#            aes(x = breaks, fill = wool)
#          ) +
#            geom_dotplot(binwidth = 1, method = "histodot") +
#            facet_grid(tension ~ .) +
#            scale_y_continuous(NULL, breaks = NULL) +
#            ggtitle("Breaks in different yarns by tension")
#        })
#  
#        output$stockTable <- render_gt({
#          # Define the start and end dates for the data range
#          start_date <- "2010-06-07"
#          end_date <- "2010-06-14"
#  
#          # Create a gt table based on preprocessed
#          # `sp500` table data
#          sp500 %>%
#            filter(date >= start_date & date <= end_date) %>%
#            select(-adj_close) %>%
#            gt() %>%
#            tab_header(
#              title = "S&P 500",
#              subtitle = glue::glue("{start_date} to {end_date}")
#            ) %>%
#            fmt_date(
#              columns = date,
#              date_style = 3
#            ) %>%
#            fmt_currency(
#              columns = c(open, high, low, close),
#              currency = "USD"
#            ) %>%
#            fmt_number(
#              columns = volume,
#              suffixing = TRUE
#            )
#        },
#        height = "100%",
#        width = "100%")
#      }
#    )
#  }

## ----eval = FALSE-------------------------------------------------------------
#  # Run this code manually to build screenshots
#  for (layout_type in names(layout_tables)) {
#    screenshot_loc <- here::here(glue("vignettes/layout-examples_{layout_type}.png"))
#    webshot2::appshot(
#      app_w_layout(new_gridlayout(layout_tables[[layout_type]])),
#      file = screenshot_loc,
#      cliprect = "viewport",
#      delay = 1.5,
#      vwidth = 1200,
#      vheight = 1000
#    )
#  
#    # Move into pkdown folder too because autodetection seems to not work
#    file.copy(
#      screenshot_loc,
#      here::here(glue("docs/articles/layout-examples_{layout_type}.png"))
#    )
#  
#  }

## ----eval = FALSE, echo = TRUE------------------------------------------------
#  ui <- grid_page(
#    layout = my_layout,
#    grid_card_text("header", "My gridlayout app"),
#    grid_card(
#      "chickens",
#      tabsetPanel(
#        tabPanel("Plot", plotOutput("chickPlot", height = "100%")),
#        tabPanel("Fastest growing", gt_output("chickTable"))
#      )
#    ),
#    grid_card(
#      "treePlot",
#      plotOutput("treePlot", height = "100%")
#    ),
#    grid_card(
#      "yarnPlot",
#      plotOutput("yarnPlot", height = "100%")
#    ),
#    grid_card(
#      "stockTable",
#      gt_output("stockTable"), scrollable = TRUE
#    ),
#    # Allows us to use layouts without some elements declared
#    flag_mismatches = FALSE
#  )

## -----------------------------------------------------------------------------
print_layout_info("stack")

## -----------------------------------------------------------------------------
print_layout_info("scrolling_stack")

## -----------------------------------------------------------------------------
print_layout_info("four_panel")

## -----------------------------------------------------------------------------
print_layout_info("focal_chart_top")

## -----------------------------------------------------------------------------
print_layout_info("focal_chart_side")

## ----ref.label=c('app_code'), eval = FALSE, echo = TRUE-----------------------
#  library(gridlayout)
#  library(shiny)
#  library(ggplot2)
#  library(gt)
#  library(dplyr)
#  library(bslib)
#  
#  app_w_layout <- function(my_layout) {
#    shinyApp(
#      ui = grid_page(
#        layout = my_layout,
#        grid_card_text("header", "My gridlayout app"),
#        grid_card(
#          "chickens",
#          card_body(
#            tabsetPanel(
#              tabPanel("Plot", plotOutput("chickPlot")),
#              tabPanel("Fastest growing", gt_output("chickTable")),
#            )
#          )
#        ),
#        grid_card_plot("treePlot"),
#        grid_card(
#           "stockTable",
#          gt_output("stockTable")
#        ),
#        flag_mismatches = FALSE # Allows us to use layouts without some elements declared
#      ),
#      server = function(input, output) {
#  
#        output$chickPlot <- renderPlot({
#          ggplot(
#            ChickWeight,
#            aes(
#              x = Time,
#              y = weight,
#              group = Chick,
#              color = Diet
#            )
#          ) +
#            geom_line(alpha = 0.5) +
#            ggtitle("Chick weights by diet")
#        })
#  
#        output$chickTable <- render_gt({
#          ChickWeight %>%
#            group_by(Chick) %>%
#            summarise(
#              `Diet` = first(Diet),
#              `start weight` = first(weight),
#              `end weight` = last(weight),
#              `weight change rate` = (last(weight) - first(weight)) / last(Time)
#            ) %>%
#            arrange(desc(`weight change rate`)) %>%
#            head(8) %>%
#            gt() %>%
#            tab_header(
#              title = "8 fastest growing chicks"
#            ) %>%
#            fmt_number(
#              columns = c(`start weight`,`end weight`),
#              pattern = "{x}<sub>g</sub>",
#              decimals = 1
#            ) %>%
#            fmt_number(
#              columns = c(`weight change rate`),
#              pattern = "{x}<sub>g/day</sub>",
#              decimals = 2
#            )
#        },
#        height = "100%",
#        width = "100%")
#  
#        output$treePlot <- renderPlot({
#          ggplot(
#            trees,
#            aes(y = Height, x = Volume, size = Girth*2)
#          ) +
#            geom_point(alpha = 0.6) +
#            scale_radius() +
#            labs(
#              title = "Tree height and volume and diameter",
#              size = "Diameter"
#            )
#        })
#  
#        output$yarnPlot <- renderPlot({
#          ggplot(
#            warpbreaks,
#            aes(x = breaks, fill = wool)
#          ) +
#            geom_dotplot(binwidth = 1, method = "histodot") +
#            facet_grid(tension ~ .) +
#            scale_y_continuous(NULL, breaks = NULL) +
#            ggtitle("Breaks in different yarns by tension")
#        })
#  
#        output$stockTable <- render_gt({
#          # Define the start and end dates for the data range
#          start_date <- "2010-06-07"
#          end_date <- "2010-06-14"
#  
#          # Create a gt table based on preprocessed
#          # `sp500` table data
#          sp500 %>%
#            filter(date >= start_date & date <= end_date) %>%
#            select(-adj_close) %>%
#            gt() %>%
#            tab_header(
#              title = "S&P 500",
#              subtitle = glue::glue("{start_date} to {end_date}")
#            ) %>%
#            fmt_date(
#              columns = date,
#              date_style = 3
#            ) %>%
#            fmt_currency(
#              columns = c(open, high, low, close),
#              currency = "USD"
#            ) %>%
#            fmt_number(
#              columns = volume,
#              suffixing = TRUE
#            )
#        },
#        height = "100%",
#        width = "100%")
#      }
#    )
#  }

