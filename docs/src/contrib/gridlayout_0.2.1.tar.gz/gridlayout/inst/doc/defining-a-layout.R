## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(gridlayout)

# Print the layout without showing mobile layouts
show_layout <- function(layout) {
  print(layout, show_alternates = FALSE)
}

## ----md_to_gridlayout---------------------------------------------------------
library(gridlayout)

table_array <- new_gridlayout(c(
  "      120px   1fr    2fr   ",
  "100px header  header header",
  "1fr   sidebar plot_a plot_b",
  "1fr   sidebar plot_c plot_c"
))

show_layout(table_array)

## -----------------------------------------------------------------------------
md_table <- new_gridlayout("
  |      |120px   |1fr    |2fr    |
  |------|--------|-------|-------|
  |100px |header  |header |header |
  |1fr   |sidebar |plot_a |plot_b |
  |1fr   |sidebar |plot_c |plot_c |"
)

show_layout(md_table)

## -----------------------------------------------------------------------------
# Assemble list of elements along with their positions
layout_elements <- list(
  list(
    id = "header", start_row = 1, end_row = 1,
    start_col = 1, end_col = 3
  ),
  list(
    id = "sidebar", start_row = 2, end_row = 3,
    start_col = 1, end_col = 1
  ),
  list(
    id = "plot_a", start_row = 2, end_row = 2,
    start_col = 2, end_col = 2
  ),
  list(
    id = "plot_b", start_row = 2, end_row = 2,
    start_col = 3, end_col = 3
  ),
  list(
    id = "plot_c", start_row = 3, end_row = 3,
    start_col = 2, end_col = 3
  )
)

elements_list <- new_gridlayout(
  layout_elements,
  col_sizes = c("120px", "1fr", "2fr"),
  row_sizes = c("100px", "1fr", "1fr")
)

show_layout(elements_list)

