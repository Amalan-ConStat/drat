## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  out.width = "100%",
  eval = FALSE
)

rmd_loc <- "demo_apps/rmarkdown_demo/grid_markdown.Rmd"

## ----eval = FALSE, echo = FALSE-----------------------------------------------
#  # Generate screenshots for this vignette
#  source(here::here("inst/demo_apps/setupScreenshots.R"))
#  
#  
#  screenshot_demo_app(
#    app_path = here::here('inst/demo_apps/', rmd_loc),
#    screenshot_name = "use_gridlayout_rmd.png",
#    screenshot_root = "vignettes",
#    vwidth = 1100
#  )
#  

## -----------------------------------------------------------------------------
#  library(gridlayout)

## ----echo=FALSE, eval=TRUE----------------------------------------------------
rmd_content <- readLines(
  system.file(rmd_loc, package = "gridlayout")
)

cat(paste(rmd_content, collapse = "\n"))

## ----echo = FALSE, message=FALSE, eval=TRUE-----------------------------------
knitr::include_graphics("use_gridlayout_rmd.png")

