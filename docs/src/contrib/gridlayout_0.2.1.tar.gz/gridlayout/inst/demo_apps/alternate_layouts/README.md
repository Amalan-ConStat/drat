## Alternate Layouts

### Purpose
Demonstrates how multiple layouts can be declared for a veriety of screen sizes. Shows that these layouts can be used for large screens in addition to just providing mobile views.

### Screenshots
- `tests/screenshot-tests/_snaps/demo-apps/alternate-layouts-mobile.png`
- `tests/screenshot-tests/_snaps/demo-apps/alternate-layouts-normal.png`
- `tests/screenshot-tests/_snaps/demo-apps/alternate-layouts-wide.png`
